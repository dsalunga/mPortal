$(document).ready(function () {
$(function() {
    $('.curved, .curved-top, .curved-bottom').each(function() {
        PIE.attach(this);
    });
});
});