﻿<%@ Control Language="C#" AutoEventWireup="true" %>
<table align="center" border="0" width="776" cellpadding="0" cellspacing="0">
    <tr>
        <td width="21%" id="topside">
        </td>
        <td height="13" id="top" valign="top">
            <img src="/Content/Assets/Images/WebSites/ADD/spacer.gif" width="740" height="1" border="0">
        </td>
        <td width="21%" id="topside">
        </td>
    </tr>
</table>
<table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0"
    width="776">
    <tr>
        <td width="776" height="23" border="0">
            <table align="right" border="0" width="10%" cellpadding="0" cellspacing="0">
                <tr>
                    <td align="right">
                        <a href="/">
                            <img border="0" src="/Content/Assets/Images/WebSites/ADD/home.gif" width="15" height="13" hspace="7"></a>
                        <a href="contact/">
                            <img border="0" src="/Content/Assets/Images/WebSites/ADD/contact.gif" width="15" height="13"></a>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td>
            <table align="left" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0"
                width="776">
                <tr>
                    <td width="18" height="106" border="0">
                    </td>
                    <td runat="server" id="phLogo">
                        <!-- // Logo
                            <img src="/Content/Assets/Images/WebSites/ADD/mcgi.gif" width="322" height="106" border="0">
                            -->
                    </td>
                    <td>
                        <img src="/Content/Assets/Images/WebSites/ADD/column.jpg" width="11" height="106" border="0"></td>
                    <td width="407" height="106" border="0" valign="top">
                        <table border="0" width="407" height="106">
                            <tr>
                                <td valign="top" id="topnews">
                                    <asp:PlaceHolder runat="server" ID="phTopNews"></asp:PlaceHolder>
                                    <!-- // TopNews
                                        <img src="/Content/Assets/Images/WebSites/ADD/jeremiah616.gif" width="131" height="22"><br>
                                        Thus saith the LORD, Stand ye in the ways, and see, and ask for the old paths, where
                                        is the good way, and walk therein, and ye shall find rest for your souls. But they
                                        said, We will not walk therein. (<strong>King James Version</strong>)
                                        -->
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="18" height="106" border="0">
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="776" border="0" id="phMenu" runat="server">
            <!-- // Menu
                <div id="nmenu">
                    <span class="menu_mcgi"><a href="/index.htm">
                        <img src="/Content/Assets/Images/WebSites/ADD/n_home.gif" name="Image1" width="49" height="21" border="0" id="Image1"
                            onmouseover="MM_swapImage('Image1','',"/Content/Assets/Images/WebSites/ADD/n_home_o.gif',1)" onmouseout="MM_swapImgRestore()"></a>
                            <img
                                src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a href="about/"><img src="/Content/Assets/Images/WebSites/ADD/n_about.gif"
                                    width="74" height="21" border="0" id="Image2" onmouseover="MM_swapImage('Image2','','/Images/WebSites/ADD/n_about_o.gif',1)"
                                    onmouseout="MM_swapImgRestore()"></a><img src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a
                                        href="biblicaltopics/"><img src="/Content/Assets/Images/WebSites/ADD/n_btopics.gif" width="119" height="21" border="0"
                                            id="Image3" onmouseover="MM_swapImage('Image3','','/Images/WebSites/ADD/n_btopics_o.gif',1)"
                                            onmouseout="MM_swapImgRestore()"></a><img src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a
                                                href="segments/"><img src="/Content/Assets/Images/WebSites/ADD/n_programs.gif" width="84" height="21" border="0"
                                                    id="Image4" onmouseover="MM_swapImage('Image4','','/Images/WebSites/ADD/n_programs_o.gif',1)"
                                                    onmouseout="MM_swapImgRestore()"></a><img src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a
                                                        href="ask/"><img src="/Content/Assets/Images/WebSites/ADD/n_ask.gif" width="94" height="21" border="0" id="Image5"
                                                            onmouseover="MM_swapImage('Image5','','/Images/WebSites/ADD/n_ask_o.gif',1)" onmouseout="MM_swapImgRestore()"></a>
                                                            <img
                                                                src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a href="publications/"><img src="/Content/Assets/Images/WebSites/ADD/n_pub.gif"
                                                                    width="107" height="21" border="0" id="Image6" onmouseover="MM_swapImage('Image6','','/Images/WebSites/ADD/n_pub_o.gif',1)"
                                                                    onmouseout="MM_swapImgRestore()"></a><img src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a
                                                                        href="media/"><img src="/Content/Assets/Images/WebSites/ADD/n_media.gif" width="51" height="21" border="0" id="Image7"
                                                                            onmouseover="MM_swapImage('Image7','','/Images/WebSites/ADD/n_media_o.gif',1)" onmouseout="MM_swapImgRestore()"></a>
                                                                            <img
                                                                                src="/Content/Assets/Images/WebSites/ADD/ndivider.gif" width="7" height="21"><a href="gallery/"><img src="/Content/Assets/Images/WebSites/ADD/n_gallery.gif"
                                                                                    width="65" height="21" border="0" id="Image8" onmouseover="MM_swapImage('Image8','','/Images/WebSites/ADD/n_gallery_o.gif',1)"
                                                                                    onmouseout="MM_swapImgRestore()"></a></span></div>
                                                                                    -->
        </td>
    </tr>
</table>
<table align="center" border="0" width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td width="27%" id="bleft">
        </td>
        <td width="740" runat="server" id="phBanner">
            <!-- // Banner
                <img src="/Content/Assets/Images/WebSites/ADD/mcgi_bibtopicts.jpg" width="740" height="116" border="0" alt="Members of the Church of God International">
                -->
        </td>
        <td width="27%" id="bright">
        </td>
    </tr>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="776">
    <tr>
        <td width="700" height="32" border="0">
            <table id="trail" align="left" border="0" width="700" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="426" height="20">
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="776">
    <tr>
        <td width="776" height="3" border="0" id="bar">
        </td>
    </tr>
</table>
<!--end here -->
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse"
    width="100%">
    <tr>
        <td align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="776">
                <tr>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td width="776" height="4">
                    </td>
                </tr>
                <tr>
                    <td>
                        <table align="left" border="0" cellpadding="0" cellspacing="0" width="776">
                            <tr>
                                <td width="772" valign="top">
                                    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse"
                                        width="100%">
                                        <tr>
                                            <td width="5">
                                            </td>
                                            <td>
                                                <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse"
                                                    width="100%">
                                                    <tr>
                                                        <td align="left" id="phPageTitle" runat="server">
                                                            <!-- // PageTitle
                                                                <img src="/Content/Assets/Images/WebSites/ADD/features.gif" width="163" height="40">
                                                                -->
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td width="3">
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="5">
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td width="776">
                        <table border="0" cellpadding="0" cellspacing="0" width="770">
                            <tr>
                                <td valign="top">
                                    <table border="0" cellpadding="0" cellspacing="0" width="770">
                                        <tr>
                                            <td height="10px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <!--begin here -->
                                                <div id="mainndx">
                                                    <div id="left-dot">
                                                    <asp:PlaceHolder ID="phMainLeft" runat="server"></asp:PlaceHolder>
                                                        <!-- // MainLeft
                                                            <span class="feat">
                                                                <h3>
                                                                    <a href="justice-for-marcos-mataro.html">On News</a></h3>
                                                                <p>
                                                                    <strong><a href="worldwide-mass-indoctrination.html">Worldwide Mass Indoctrination</a></strong></p>
                                                                <p>
                                                                    Learn Christian doctrines in a new series of Mass Indoctrination that will commence
                                                                    on Monday (January 19, 2009) in all major A.D.D. coordinating centers worldwide
                                                                    [&hellip;] <a href="worldwide-mass-indoctrination.html">
                                                                        <img border="0" src="/Content/Assets/Images/WebSites/ADD/more.gif" width="39" height="12" align="absbottom"></a>
                                                                </p>
                                                                <p>
                                                                    <strong><a href="justice-for-marcos-mataro.html">CRY FOR JUSTICE - Marcos Mataro killing:
                                                                        serious blow against freedom of expression, religion</a></strong></p>
                                                                <p>
                                                                    It was like any normal Sunday morning on April 27, except for the cloudy sky and
                                                                    mildly gushing of wind that was threatening for rain to fall. At the North Luzon
                                                                    Expressway toll gate in San Simon, Pampanga, at past 10am, [&hellip;] <a href="justice-for-marcos-mataro.html">
                                                                        <img border="0" src="/Content/Assets/Images/WebSites/ADD/more.gif" width="39" height="12" align="absbottom"></a>
                                                                </p>
                                                            </span><span class="feat">
                                                                <h3>
                                                                    <a href="http://esoriano.wordpress.com" target="_blank">On Wordpress Blog</a></h3>

                                                                <script type="text/javascript">
                    var theblog=new gfeedfetcher("blog", "blog", "_blank")
                    theblog.addFeed(" — Bro. Eli Soriano", "http://esoriano.wordpress.com/feed")
                    theblog.displayoptions("label snippet")
                    theblog.setentrycontainer("p")
                    theblog.filterfeed(3, "date")
                    theblog.init()
                                                                </script>

                                                                <p>
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/theblogmag.jpg" alt="" align="middle" />
                                                                    Download a copy of <strong><a href="publications/publications.htm">The Blog Magazine</a></strong>
                                                                    as
                                                                    <abbr title="Portable Document Format">
                                                                        PDF</abbr>
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/pdf.gif" border="0" /></p>
                                                            </span><span class="feat">
                                                                <h3>
                                                                    <a href="http://www.youtube.com/broelisoriano" target="_blank">On Youtube</a></h3>
                                                                <div id="youtubeDivUser" align="center">

                                                                    <script>insertVideos('youtubeDivUser','user','broelisoriano','3',0);</script>

                                                                </div>
                                                            </span><span class="feat">
                                                                <h3>
                                                                    <a href="http://www.talkshoe.com/talkshoe/web/tscmd/tc/56964" target="_blank">On Talkshoe
                                                                        Podcast</a></h3>
                                                                <div class="reltop" style="list-style: url(images/podcast.png);">

                                                                    <script type="text/javascript">
                    var tokshu=new gfeedfetcher("podcast", "podcast", "_blank")
                    tokshu.addFeed("", "http://recordings.talkshoe.com/rss56964.xml")
                    tokshu.displayoptions("label snippet")
                    tokshu.setentrycontainer("li")
                    tokshu.filterfeed(7, "date")
                    tokshu.init()
                                                                    </script>

                                                                </div>
                                                                <p>
                                                                </p>
                                                            </span><span class="feat2">
                                                                <h3>
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/ndx_bib.jpg" width="186" height="36"></h3>
                                                                <p>
                                                                    <strong>There is something that God cannot do</strong></p>
                                                                <p>
                                                                    Many religious groups believe that God can do everything and anything because He
                                                                    is omnipresent, omnipotent, and omniscient. But, do you know that there is something,
                                                                    which God cannot do? It is true that all [&hellip;] <a href="biblicaltopics/bib_issues_13.htm">
                                                                        <img border="0" src="/Content/Assets/Images/WebSites/ADD/more.gif" width="39" height="12" align="absbottom"></a></p>
                                                                <div class="reltop">
                                                                    <ul>
                                                                        <li><a href="biblicaltopics/bib_issues_3.htm">Different Issues Concerning Faith</a></li>
                                                                        <li><a href="biblicaltopics/bib_issues_12.htm">There is No Such Thing as Reincarnation</a></li>
                                                                        <li><a href="biblicaltopics/bib_christ_2.htm">The Pre-Existence of our Lord Jesus Christ</a></li>
                                                                    </ul>
                                                                </div>
                                                                <br />
                                                            </span><span class="feat2">
                                                                <h3>
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/ndx_ask.jpg" width="155" height="36"></h3>
                                                                <p>
                                                                    Question: How, where and since when does the Catholic images and pictures, which
                                                                    they worship at present, originated? As well as the rosary and the holy water?<a
                                                                        href="ask/ask_broeli_1f.htm"><img border="0" src="/Content/Assets/Images/WebSites/ADD/read_bro.gif" width="129"
                                                                            height="22" align="right" /></a><br />
                                                                    <br />
                                                                </p>
                                                            </span><span class="feat2">
                                                                <h3>
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/ndx_tif.jpg" width="186" height="36"></h3>
                                                                <p>
                                                                    <strong>Almighty God: Proof of His Existence</strong></p>
                                                                <p>
                                                                    Who named God? What are the names given to Him? These are relevant questions that
                                                                    require an intelligent answer. Inasmuch as man is the one that assigns names to
                                                                    his fellowman, and man is a mere creation of God, it is, therefore, illogical, unbecoming
                                                                    and even absurd that a mere [&hellip;] <a href="segments/seg_focus_3.htm">
                                                                        <img border="0" src="/Content/Assets/Images/WebSites/ADD/more.gif" width="39" height="12" align="absbottom"></a></p>
                                                            </span>
                                                            -->
                                                    </div>
                                                    <div id="right-dot">
                                                    <asp:PlaceHolder ID="phMainRight" runat="server"></asp:PlaceHolder>
                                                        <!-- // MainRight
                                                            <img src="/Content/Assets/Images/WebSites/ADD/eventsched.gif" width="241" height="29">
                                                            <iframe class="eventsched" src="http://www.google.com/calendar/embed?src=89n9sa2srfbemh796q6qv60m2g%40group.calendar.google.com&showTitle=0&showDate=0&showPrint=0&showNav=0&showTabs=0&showCalendars=0&showTz=0&mode=AGENDA&height=220&wkst=1&bgcolor=%23F9F7F0&color=%23B1365F&ctz=Asia/Manila&hl=en"
                                                                style="border: 0" width="220" height="220" frameborder="0" scrolling="no">
                                                                <p>
                                                                    For more info, just call: (632)4558480; (632)4558482; (632)4558484; (6345)8790522</p>
                                                            </iframe>
                                                            <img src="/Content/Assets/Images/WebSites/ADD/programsched.gif" width="253" height="29">
                                                            <div class="progsched">
                                                                <b>TOP CHANNEL FREQUENCY<br>
                                                                    Satellite Coverage</b>: USA, CANADA<br>
                                                                Transponder = tp24<br>
                                                                Polarity = Horizontal<br>
                                                                Down Frequency = 12123 mhz<br>
                                                                Symbol Rate = 22000 ksps<br>
                                                                FEC = 3/4<br>
                                                                <br>
                                                                <b>TV STATION<br>
                                                                    <a href="http://www.untvweb.com">UNTV 37 </a></b>
                                                                <br>
                                                                Monday - Friday | 10:30 am<br />
                                                                Monday - Friday | 12:03 pm<br />
                                                                Monday - Friday | 08:25 pm<br />
                                                                Monday - Friday | 10:05 pm<br />
                                                                Monday - Friday | 01:30 am<br />
                                                                <br />
                                                                Satudays | 07:00 am<br />
                                                                Satudays | 09:00 pm<br />
                                                                Satudays | 01:30 am<br />
                                                                <br />
                                                                Sundays | 07:00 am<br />
                                                                Sundays | 12:00 pm<br />
                                                                Sundays | 09:00 pm<br />
                                                                Sundays | 01:30 am<br />
                                                                <br>
                                                                <b>RADIO STATION</b><br>
                                                                <b>100 Radyo Natin Stations</b><br>
                                                                Monday – Sunday | 8:30 pm – 10:00 pm
                                                                <br>
                                                                <br>
                                                                <b>558 RMN News Manila</b><br>
                                                                Monday – Friday | 9:00 pm – 12:00 mn
                                                                <br>
                                                                <br>
                                                                <b>DZRH</b><br>
                                                                Monday – Friday | 12:00 mn – 1:00 am<br>
                                                                Sunday | 10:00 pm – 12:15 am
                                                                <br>
                                                                <br>
                                                                Simulcast: TOP Channel – 9-12 mn
                                                                <br>
                                                                <hr />
                                                                <p align="center">
                                                                    <a href="http://www.philippinewebawards.com" target="_blank">
                                                                        <img src="/Content/Assets/Images/WebSites/ADD/pwa_finalist.gif" alt="PWA Finalist" width="100" height="101" border="0" /></a></p>
                                                                <p align="center">
                                                                    11th Philippine Web Awards<br />
                                                                    <br />
                                                                    For SMS voting, just text
                                                                    <br />
                                                                    <strong>WEBBYS VOTE 69</strong><br />
                                                                    then send to
                                                                    <br />
                                                                    <strong>2973</strong>(Globe/TM)
                                                                    <br />
                                                                    or <strong>2955</strong>(Smart/TNT)<br />
                                                                    <br />
                                                                    For online voting, login or register your account at <a href="http://www.philippinewebawards.com"
                                                                        target="_blank">PWA</a> then go to the Members Lounge and click "Vote for a
                                                                    Site" link.</p>
                                                            </div>
                                                            -->
                                                    </div>
                                                    <!--end here -->
                                                    <div id="feat_site">
                                                        <h3 align="left" runat="server" id="phColumnsTitle">
                                                            <!-- // ColumnsTitle
                                                                <img src="/Content/Assets/Images/WebSites/ADD/relatedsites.gif" width="170" height="29">
                                                                -->
                                                        </h3>
                                                        <div id="feat">
                                                            <span class="dottv" id="phColumnLeft" runat="server">
                                                                <!-- // ColumnLeft
                                                                <a href="http://www.theoldpath.tv">
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/thumb_top.jpg" width="216" height="74" border="0"></a>
                                                                    <p>
                                                                        <a href="http://www.theoldpath.tv">The Old Path TV</a></p>
                                                                    Watch “<strong>Ang Dating Daan</strong>” (<strong>The Old Path</strong>) Internet
                                                                    Broadcast through Philippine Web Awards People’s Choice victor—The Old Path Video
                                                                    Streaming Website, a 24-hour, multi-platform, broadband quality Internet broadcast
                                                                    in the digital broadband space. In the greatly enhanced video streaming capabilities
                                                                    of the site that is playable using Windows and Real Media players and more on-demand
                                                                    features, online viewers can select and add video clips on our virtual jukebox or
                                                                    playlist.
                                                                    -->
                                                            </span><span class="tc" id="phColumnMiddle" runat="server">
                                                                <!-- // ColumnMiddle
                                                                    <a href="http://www.truthcaster.com">
                                                                        <img src="/Content/Assets/Images/WebSites/ADD/thumb_tc.jpg" width="216" height="74" border="0"></a>
                                                                        <p>
                                                                            <a href="http://www.truthcaster.com">Truthcaster</a></p>
                                                                        <strong>Truthcaster</strong> is an online streaming media channel featuring Bro.
                                                                        Eli Soriano's live webcast of scheduled bible expositions of religious issues that
                                                                        grapple in our present generation. Site visitors and audience may also get to ask
                                                                        Bro. Eli during live webcasts their questions about their faith and understanding
                                                                        of issues that they would want to be enlightened upon using the Bible as basis.
                                                                        -->
                                                            </span><span class="kaanib" id="phColumnRight" runat="server">
                                                                <!-- // ColumnRight
                                                                <a href="http://www.kaanib.net">
                                                                    <img src="/Content/Assets/Images/WebSites/ADD/thumb_kaanib.jpg" width="216" height="74" border="0"></a>
                                                                    <p>
                                                                        <a href="http://www.kaanib.net">Kaanib.NET</a></p>
                                                                    The new <strong>Kaanib.net</strong> serve as a one-stop community and portal website
                                                                    for the global members of the Church of God International with features and web
                                                                    enhancements that will keep everyone connected in line with Christian tenets in
                                                                    the Bible. The new site, which highlights the theme, “<strong>Christian unity is unity
                                                                        in love</strong>,” aims to promote any member’s highest ideals, creativity and
                                                                    faith through free expression of thoughts, opinion and aspirations; anyway, “<strong>It
                                                                        is all about us!</strong>”
                                                                        -->
                                                            </span>
                                                        </div>
                                                    </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td id="phFooter" runat="server">
                                    <!-- // Footer
                                        <table align="center" border="0" cellpadding="0" cellspacing="0" width="776">
                                            <tr>
                                                <td width="776" height="3" border="0" id="bar">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="776" height="30" border="0" id="up_footer">
                                                    <a href="disclaimer.htm">Copyright/Disclaimer</a> | <a href="policy.htm">Privacy Policy</a>
                                                    | <a href="contact/">Contact Us</a>
                                                </td>
                                            </tr>
                                        </table>
                                        <table align="center" border="0" cellpadding="0" cellspacing="0" width="776">
                                            <tr>
                                                <td width="776" border="0">
                                                    <table border="0" width="100%" cellpadding="0" cellspacing="0">
                                                        <tr>
                                                            <td id="footer">
                                                                Produced through the help of the ALMIGHTY GOD by the<br>
                                                                Members CHURCH OF GOD International<br>
                                                                Copyright &copy 2000-2007, MCGI, All Rights Reserved
                                                            </td>
                                                            <td width="357">
                                                                <img border="0" src="/Content/Assets/Images/WebSites/ADD/divider.gif" width="15" height="50"><img border="0" src="/Content/Assets/Images/WebSites/ADD/below_logo.gif"
                                                                    width="175" height="50">
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                        -->
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<a href="thanksgiving_2008dec22.jpg" rel="lytebox" id="papap" title="Thanksgiving Offering (Dec. 22-23, 2007)">
</a>