<%@ Control Language="C#" AutoEventWireup="true" %>
<table border="0" cellspacing="0" cellpadding="0" width="776" align="center">
    <tbody>
        <tr>
            <td id="topside" width="21%">
            </td>
            <td id="top" height="13" valign="top">
                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/spacer.gif" width="740"
                    height="1">
            </td>
            <td id="topside" width="21%">
            </td>
        </tr>
    </tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" width="776" bgcolor="#ffffff" align="center">
    <tbody>
        <tr>
            <td height="23" width="776" border="0">
                <table border="0" cellspacing="0" cellpadding="0" width="10%" align="right">
                    <tbody>
                        <tr>
                            <td align="right">
                                <a href="http://www.angdatingdaan.org/">
                                    <img border="0" hspace="7" src="Ang%20Dating%20Daan%20-%20About%20Us_files/home.gif"
                                        width="15" height="13"></a> <a href="http://www.angdatingdaan.org/contact/">
                                            <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/contact.gif" width="15"
                                                height="13"></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table border="0" cellspacing="0" cellpadding="0" width="776" bgcolor="#ffffff" align="left">
                    <tbody>
                        <tr>
                            <td height="106" width="18" border="0">
                            </td>
                            <td>
                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/mcgi.gif" width="322"
                                    height="106">
                            </td>
                            <td>
                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/column.jpg" width="11"
                                    height="106">
                            </td>
                            <td height="106" valign="top" width="407" border="0">
                                <table border="0" width="407" height="106">
                                    <tbody>
                                        <tr>
                                            <td id="topnews" valign="top">
                                                <img src="Ang%20Dating%20Daan%20-%20About%20Us_files/jeremiah616.gif" width="131"
                                                    height="22"><br>
                                                Thus saith the LORD, Stand ye in the ways, and see, and ask for the old paths, where
                                                is the good way, and walk therein, and ye shall find rest for your souls. But they
                                                said, We will not walk therein. (King James Version)
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td height="106" width="18" border="0">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td width="776" border="0">
                <div id="nmenu">
                    <span class="menu_mcgi"><a href="http://www.angdatingdaan.org/">
                        <img id="Image1" onmouseover="MM_swapImage('Image1','','/images/n_home_o.gif',1)"
                            onmouseout="MM_swapImgRestore()" border="0" name="Image1" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_home.gif"
                            width="49" height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                width="7" height="21"><a href="http://www.angdatingdaan.org/about/"><img id="Image2"
                                    onmouseover="MM_swapImage('Image2','','/images/n_about_o.gif',1)" onmouseout="MM_swapImgRestore()"
                                    border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_about.gif" width="74"
                                    height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                        width="7" height="21"><a href="http://www.angdatingdaan.org/biblicaltopics/"><img
                                            id="Image3" onmouseover="MM_swapImage('Image3','','/images/n_btopics_o.gif',1)"
                                            onmouseout="MM_swapImgRestore()" border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_btopics.gif"
                                            width="119" height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                                width="7" height="21"><a href="http://www.angdatingdaan.org/segments/"><img id="Image4"
                                                    onmouseover="MM_swapImage('Image4','','/images/n_programs_o.gif',1)" onmouseout="MM_swapImgRestore()"
                                                    border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_programs.gif" width="84"
                                                    height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                                        width="7" height="21"><a href="http://www.angdatingdaan.org/ask/"><img id="Image5"
                                                            onmouseover="MM_swapImage('Image5','','/images/n_ask_o.gif',1)" onmouseout="MM_swapImgRestore()"
                                                            border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_ask.gif" width="94"
                                                            height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                                                width="7" height="21"><a href="http://www.angdatingdaan.org/publications/"><img id="Image6"
                                                                    onmouseover="MM_swapImage('Image6','','/images/n_pub_o.gif',1)" onmouseout="MM_swapImgRestore()"
                                                                    border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_pub.gif" width="107"
                                                                    height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                                                        width="7" height="21"><a href="http://www.angdatingdaan.org/media/"><img id="Image7"
                                                                            onmouseover="MM_swapImage('Image7','','/images/n_media_o.gif',1)" onmouseout="MM_swapImgRestore()"
                                                                            border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_media.gif" width="51"
                                                                            height="21"></a><img src="Ang%20Dating%20Daan%20-%20About%20Us_files/ndivider.gif"
                                                                                width="7" height="21"><a href="http://www.angdatingdaan.org/gallery/"><img id="Image8"
                                                                                    onmouseover="MM_swapImage('Image8','','/images/n_gallery_o.gif',1)" onmouseout="MM_swapImgRestore()"
                                                                                    border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/n_gallery.gif" width="65"
                                                                                    height="21"></a></span></div>
            </td>
        </tr>
    </tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" width="100%" align="center">
    <tbody>
        <tr>
            <td id="bleft" width="27%">
            </td>
            <td width="740">
                <img border="0" alt="Members of the Church of God International" src="Ang%20Dating%20Daan%20-%20About%20Us_files/mcgi_about_us.jpg"
                    width="740" height="116">
            </td>
            <td id="bright" width="27%">
            </td>
        </tr>
    </tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" width="776" align="center">
    <tbody>
        <tr>
            <td height="32" width="700" border="0">
                <table id="trail" border="0" cellspacing="0" cellpadding="0" width="700" align="left">
                    <tbody>
                        <tr>
                            <td height="20" width="426">
                                <a href="http://www.angdatingdaan.org/">Home</a><img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/arrow.gif"
                                    width="14" height="7">
                                <a href="http://www.angdatingdaan.org/about/">About Us</a><img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/arrow.gif"
                                    width="14" height="7">
                                <a href="http://www.angdatingdaan.org/about/about_us.htm#">About this Site</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" width="776" align="center">
    <tbody>
        <tr>
            <td id="bar" height="3" width="776" border="0">
            </td>
        </tr>
    </tbody>
</table>
<!--end here -->
<table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
    width="100%">
    <tbody>
        <tr>
            <td align="middle">
                <table border="0" cellspacing="0" cellpadding="0" width="776">
                    <tbody>
                        <tr>
                            <td>
                            </td>
                        </tr>
                        <tr>
                            <td height="4" width="776">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table border="0" cellspacing="0" cellpadding="0" width="776" align="left">
                                    <tbody>
                                        <tr>
                                            <td valign="top" width="229">
                                                <table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td width="5">
                                                            </td>
                                                            <td>
                                                                <table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
                                                                    width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                                <img src="Ang%20Dating%20Daan%20-%20About%20Us_files/nb_about.gif" width="221" height="40">
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                            <td width="3">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="5" width="5">
                                                            </td>
                                                            <td height="5">
                                                            </td>
                                                            <td height="5" width="3">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="5" width="5">
                                                            </td>
                                                            <td height="5">
                                                            </td>
                                                            <td height="5" width="3">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td width="5">
                                                            </td>
                                                            <td>
                                                                <table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
                                                                    width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td id="left_table">
                                                                                <table border="0" cellspacing="0" cellpadding="0" width="206">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_mcgi.htm">About MCGI</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_chistory.htm">Church History</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_ministries.htm">Ministries</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_mission.htm">Mission and
                                                                                                        Discipline</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_doctrines.htm">Basic Doctrines</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_ministers.htm">Biographies</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/about/about_faq.htm">What is "Ang Dating
                                                                                                        Daan"?</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="3">
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td id="linkage">
                                                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ar_row.gif" width="9"
                                                                                                    height="8"><a href="http://www.angdatingdaan.org/contact/">Contact Us</a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                            <td width="3">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="10" width="5">
                                                            </td>
                                                            <td height="10">
                                                            </td>
                                                            <td height="10" width="3">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td id="mbar" width="5">
                                            </td>
                                            <td valign="top" width="536">
                                                <table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td width="4">
                                                            </td>
                                                            <td>
                                                                <table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
                                                                    width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td id="bg">
                                                                                About this Site
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                            <td width="4">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="5" width="4">
                                                            </td>
                                                            <td height="5">
                                                            </td>
                                                            <td height="5" width="4">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td width="4">
                                                            </td>
                                                            <td>
                                                                <table style="border-collapse: collapse" border="0" cellspacing="0" cellpadding="0"
                                                                    width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td id="mid">
                                                                                <br>
                                                                                <img border="0" hspace="0" align="left" src="Ang%20Dating%20Daan%20-%20About%20Us_files/ltr_t.gif"
                                                                                    width="29" height="25">he Ang Dating Daan Bible Exposition Online is the official
                                                                                website of “<b>Ang Dating Daan</b>”—the only religious program which heightens people’s
                                                                                religious awareness by studying the truths in the Bible.
                                                                                <br>
                                                                                <br>
                                                                                The fervent objective of the radio and television program is maintained in our online
                                                                                media format. It upholds the divine mission to propagate the true Gospel of Christ
                                                                                based on the Bible and converts sinners to believe and glorify God. It also believes
                                                                                that only the Church can teach the wisdom of God for the salvation of mankind.<br>
                                                                                <br>
                                                                                Our website features timely and relevant Bible Expositions and public discussions,
                                                                                television segments, exposés, the highly-popular <b>Itanong mo kay Soriano</b> (Ask
                                                                                Soriano) segment, religious references, and doctrines, among others.
                                                                                <br>
                                                                                <br>
                                                                                When launched in 2000, the MEMBERS OF THE CHURCH OF GOD INTERNATIONAL made a bold
                                                                                step in reaching out to many people worldwide, together with the streaming media
                                                                                platform called <a href="http://www.theoldpath.tv/">http://www.theoldpath.tv/</a>
                                                                                .<br>
                                                                                <br>
                                                                                Since then, “<b>Ang Dating Daan</b>” was heard and seen in the whole world. Membership
                                                                                soared and new local chapters were established in North America, Canada, Europe,
                                                                                Africa, and even the Asia Pacific, China and Australia.
                                                                                <br>
                                                                                <br>
                                                                                In 2002, our website made history when the 5th Philippine Web Awards picked out
                                                                                Ang Dating Daan Bible Exposition Online for the Yehey's MOST POPULAR WEBSITE and
                                                                                the PEOPLE’S CHOICE AWARD in the BEST ORGANIZATION CATEGORY. Over 2,000 Philippine
                                                                                websites vied for the top site in this annual website competition.
                                                                                <br>
                                                                                <br>
                                                                                On the other hand, “<b>Ang Dating Daan</b>,” which already carved its mark since
                                                                                its inception over 20 years ago in Philippine broadcast history, can be seen worldwide
                                                                                via satellite through the facilities of UN Television UHF Channel 37 and heard over
                                                                                the most powerful radio networks – DZRH, RMN and 100 Radyo Nation Stations nationwide.
                                                                                <br>
                                                                                <br>
                                                                                Brother Eliseo F. Soriano, considered as the only sensible evangelist today, hosts
                                                                                the radio and television programs, together with Bros. Josel Mallari, Danny Navales,
                                                                                Willy Santiago and Sis. Luz Cruz.
                                                                                <br>
                                                                                <br>
                                                                                The <b>Ang Dating Daan Bible Exposition Online</b>, with satellite offices all over
                                                                                the country and several countries around the globe, can be contacted in its central
                                                                                headquarters in ADD Convention Center, Brgy. Sampaloc, Apalit, Pampanga.<br>
                                                                                <br>
                                                                                <br>
                                                                                <a href="http://www.angdatingdaan.org/about/about_us.htm#top">
                                                                                    <img border="0" hspace="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/totop.gif"
                                                                                        width="76" height="23"></a><br>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                            <td width="4">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td height="5" width="4">
                                                            </td>
                                                            <td height="5">
                                                            </td>
                                                            <td height="5" width="4">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                            <td width="5">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td width="776">
                                <table border="0" cellspacing="0" cellpadding="0" width="776" align="center">
                                    <tbody>
                                        <tr>
                                            <td id="bar" height="3" width="776" border="0">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td id="up_footer" height="30" width="776" border="0">
                                                <a href="http://www.angdatingdaan.org/disclaimer.htm">Copyright/Disclaimer</a> |
                                                <a href="http://www.angdatingdaan.org/policy.htm">Privacy Policy</a> | <a href="http://www.angdatingdaan.org/contact/">
                                                    Contact Us</a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table border="0" cellspacing="0" cellpadding="0" width="776" align="center">
                                    <tbody>
                                        <tr>
                                            <td width="776" border="0">
                                                <table border="0" cellspacing="0" cellpadding="0" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td id="footer">
                                                                Produced through the help of the ALMIGHTY GOD by the<br>
                                                                Members CHURCH OF GOD International<br>
                                                                Copyright © 2000-2007, MCGI, All Rights Reserved
                                                            </td>
                                                            <td width="357">
                                                                <img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/divider.gif" width="15"
                                                                    height="50"><img border="0" src="Ang%20Dating%20Daan%20-%20About%20Us_files/below_logo.gif"
                                                                        width="175" height="50">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
